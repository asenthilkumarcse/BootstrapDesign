﻿namespace AddBot.Web.Models
{
    public class BotSkillMaster
    {
        public int BotSkillID { get; set; }
        public int BotID { get; set; }
        public string SkillName { get; set; }
    }
}
