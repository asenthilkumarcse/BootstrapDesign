﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AddBot.Web.Models
{
    public class BotImageDetails
    {
        public int BotImageID { get; set; }
        public string BotImageName { get; set; }
    }
}
