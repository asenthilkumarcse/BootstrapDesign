﻿using System.Collections.Generic;

namespace AddBot.Web.Models
{
    public class BotMasterModel
    {
        public string BotName { get; set; }
        public string BotStatus { get; set; }
        public int? BotImageID { get; set; }
        public string SkillName { get; set; }
    }
}
