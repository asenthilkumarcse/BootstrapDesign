﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AssignBot.Web.Models;
using AssignBot.Web.Utilities.HttpClientFactories.Interface;
using Microsoft.AspNetCore.Mvc;

namespace AssignBot.Web.Controllers
{
    public class AssignBotController : Controller
    {
        private static List<BotAttributeMaster> botAttributeMasters = new List<BotAttributeMaster>();
        private static List<BotIntendMaster> botIntendMasters = new List<BotIntendMaster>();
        private static List<BotSkillMaster> botSkillMasters = new List<BotSkillMaster>();
        //private static List<> botSkillMasters = new List<BotSkillMaster>();
        private static BotMaster botMasterEdit;
        private static int botSkillMasterId;
        private readonly IAssignBotClient _assignBotClient;
        public AssignBotController(IAssignBotClient assignBotClient)
        {
            this._assignBotClient = assignBotClient;
        }
        public async Task<IActionResult> Index()
        {
            @ViewBag.BotImageDetails = await _assignBotClient.GetBotImageDetails();
            return View();
        }

        public async Task<IActionResult> AssignBot(int Id)
        {
            @ViewBag.BotImageDetails = await _assignBotClient.GetBotImageDetails();
            //@ViewBag.BotTeamDetails = await _assignBotClient.GetBotTeamDetails();
            var BotTeamDetailsList = await _assignBotClient.GetBotTeamDetails();
            BotTeamDetailsList.Insert(0, new TeamListing { TeamID = 0, TeamName = "Select Team ..." });
            @ViewBag.BotTeamDetails = BotTeamDetailsList;

            BotListDetails botListDetails = await _assignBotClient.GetBotDetailsById(Id);
            BotMasterModel botMasterModel = new BotMasterModel
            {
                BotName = botListDetails.BotMasters.BotName,
                BotImageID = botListDetails.BotMasters.BotImageID,
                BotStatus = botListDetails.BotMasters.Active ? "true" : "false",
                SkillName = botListDetails.BotSkillMasters[0].SkillName,
            };
            botSkillMasterId = botListDetails.BotSkillMasters[0].BotSkillID;
            botMasterEdit = botListDetails.BotMasters;
            botAttributeMasters = botListDetails.BotAttributeMasters;
            botIntendMasters = botListDetails.BotIntendMasters;

            @ViewBag.botAttributeMasters = botAttributeMasters;
            @ViewBag.botIntendMasters = botIntendMasters;

            return View(botMasterModel);
        }

        public async Task<IActionResult> SaveAssignBot()
        {
            BotListDetails botListDetails = new BotListDetails();
            bool.TryParse(Convert.ToString(HttpContext.Request.Form["BotStatus"]), out bool isAvailable);
            BotMaster botMaster = new BotMaster
            {
                BotID = botMasterEdit.BotID,
                BotName = Convert.ToString(HttpContext.Request.Form["BotName"]),
                Active = isAvailable,
                BotImageID = Convert.ToInt32(HttpContext.Request.Form["BotImageID"]),
                CreatedBy = 1,
                CreatedTime = DateTime.Now
            };

            List<BotSkillMaster> botSkillMasters = new List<BotSkillMaster>
            {
                new BotSkillMaster{BotID =botMasterEdit.BotID,  BotSkillID= botSkillMasterId, SkillName = Convert.ToString(HttpContext.Request.Form["SkillName"]) }
            };

            botListDetails.BotMasters = botMaster;
            botListDetails.BotSkillMasters = botSkillMasters;
            botListDetails.BotAttributeMasters = botAttributeMasters;
            botListDetails.BotIntendMasters = botIntendMasters;

            await _assignBotClient.SaveBotDetails(botListDetails);

            ResetValues();
            return RedirectToAction("Index", "BotDashboard");
        }
        private void ResetValues()
        {
            botAttributeMasters = new List<BotAttributeMaster>();
            botIntendMasters = new List<BotIntendMaster>();
            botSkillMasters = new List<BotSkillMaster>();
            botMasterEdit = new BotMaster();
            botSkillMasterId = 0;
        }
        public IActionResult BotAssignment()
        {
            return View();
        }
    }
}