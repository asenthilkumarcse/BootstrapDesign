﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AssignBot.Web.Utilities.HttpClientFactories.Interface;
using Microsoft.AspNetCore.Mvc;

namespace AssignBot.Web.Controllers
{
    public class BotDashboardController : Controller
    {
        private readonly IAssignBotClient _assignBotClient;
        public BotDashboardController(IAssignBotClient assignBotClient)
        {
            this._assignBotClient = assignBotClient;
        }
        public async Task<IActionResult> IndexAsync()
        {
            var response = await _assignBotClient.GetBotDetails();
            return View(response);
        }
    }
}
