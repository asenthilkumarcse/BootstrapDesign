﻿using AssignBot.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AssignBot.Web.Utilities.HttpClientFactories.Interface
{
    public interface IAssignBotClient
    {
        Task<BotListing> GetBotDetails();
        Task SaveBotDetails(BotListDetails botListDetails);
        Task<BotListDetails> GetBotDetailsById(int id);
        Task<List<BotImageDetails>> GetBotImageDetails();
        Task<List<TeamListing>> GetBotTeamDetails();

    }
}
