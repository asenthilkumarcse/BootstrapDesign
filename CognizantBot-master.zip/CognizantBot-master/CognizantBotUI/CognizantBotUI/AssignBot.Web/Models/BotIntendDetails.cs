﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AssignBot.Web.Models
{
    public class BotIntendDetails
    {
        public int IntendDetailID { get; set; }
        public int AssignmentID { get; set; }
        public int IntendMasterID { get; set; }
        public int IntendValue { get; set; }
    }
}
