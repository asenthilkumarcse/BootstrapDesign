﻿namespace AssignBot.Web.Models
{
    public class BotIntendMaster
    {
        public int BotIntendID { get; set; }
        public int BotID { get; set; }
        public string IntendName { get; set; }
    }
}
