﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AssignBot.Web.Models
{
    public class BotListing
    {
        public List<BotMaster> BotMasters { get; set; }
        public List<BotIntendMaster> BotIntendMasters { get; set; }
        public List<BotSkillMaster> BotSkillMasters { get; set; }
        public List<BotAttributeMaster> BotAttributeMasters { get; set; }
    }
}
