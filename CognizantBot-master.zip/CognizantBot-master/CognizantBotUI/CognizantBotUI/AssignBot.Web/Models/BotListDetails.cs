﻿using System.Collections.Generic;

namespace AssignBot.Web.Models
{
    public class BotListDetails
    {
        public BotMaster BotMasters { get; set; }
        public List<BotIntendMaster> BotIntendMasters { get; set; }
        public List<BotSkillMaster> BotSkillMasters { get; set; }
        public List<BotAttributeMaster> BotAttributeMasters { get; set; }
        public TeamListing TeamListing { get; set; }
        public List<BotAttributeDetails> BotAttributeDetails { get; set; }
        public List<BotIntendDetails> BotIntendDetails { get; set; }
    }
}
