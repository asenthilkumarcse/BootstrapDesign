﻿namespace AssignBot.Web.Models
{
    public class BotAttributeMaster
    {
        public int BotAttributeID { get; set; }
        public int BotID { get; set; }
        public string AttributeName { get; set; }
    }
}
