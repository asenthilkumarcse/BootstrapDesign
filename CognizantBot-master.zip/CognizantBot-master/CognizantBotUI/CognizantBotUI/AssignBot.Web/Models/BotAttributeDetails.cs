﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AssignBot.Web.Models
{
    public class BotAttributeDetails
    {
        public int AttributeDetailID { get; set; }
        public int AssignmentID { get; set; }
        public int AttributeMasterID { get; set; }
        public string AttributeValue { get; set; }
    }
}
