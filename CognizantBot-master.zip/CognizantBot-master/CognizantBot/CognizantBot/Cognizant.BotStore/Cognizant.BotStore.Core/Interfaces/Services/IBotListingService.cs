﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IBotListingService
    {
        BotListing GetBotDetails();
    }
}
